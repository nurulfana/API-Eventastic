<footer class="indigo page-footer">
      <div class="container">
         <span>Made By <a style='font-weight: bold;'>Tirth Patel</a> & <a style='font-weight: bold;'>Nurul Fana</a></span>
      </div>
  </footer>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
      
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.min.js"></script>